IMAGES
------

Place custom images for the child theme here. Such as images referred to by custom css and js.
