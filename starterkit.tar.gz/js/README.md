JS Scripts
----------

The Shanti Sarvaka theme comes with shanti-main.js and shanti-search.js for those two aspects. 
A sub-theme should similarly have shanti-main-{subtheme name}.js and shanti-search-{subtheme name}.js
Use the two empty files shanti-main-STARTERKIT.js and shanti-search-STARTERKIT.js to create those
