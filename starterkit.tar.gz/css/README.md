CSS
---

The Shanti Sarvaka theme comes with shanti-main.css and shanti-search.css for those two aspects. 
A sub-theme should similarly have shanti-main-{subtheme name}.css and shanti-search-{subtheme name}.css
Use the two empty files shanti-main-STARTERKIT.css and shanti-search-STARTERKIT.css to create those
